from helloflask import app

app.run(host='0.0.0.0')  # 127.0.0.1 == localhost
